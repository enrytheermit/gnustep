#!/bin/bash

# 'source' GNUstep.sh
. /usr/local/share/GNUstep/Makefiles/GNUstep.sh

