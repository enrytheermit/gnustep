#!/bin/bash

export ANDROID_NDK="${ANDROID_GNUSTEP_INSTALL_ROOT}/android-ndk-r8d"
export ANDROID_NDK_LLVM="${ANDROID_GNUSTEP_INSTALL_ROOT}/android-ndk-r8d/toolchains/llvm-3.1/prebuilt/linux-x86/bin/"
