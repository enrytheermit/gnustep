#!/bin/bash

export CC=gcc
export OBJCC=gcc
export CXX=g++
